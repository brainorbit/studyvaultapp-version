package com.sleepyhead.studyvault

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    companion object {
        private const val HOST = "studyvault.alwaysdata.net"
        private const val START_URL = "https://$HOST/welcome"
        const val EXTRA_URL = "url"
        private const val PREFS = "sv"
        // Pages where pull-to-refresh would fight the page (video player).
        private val NO_REFRESH_PATHS = listOf("/watch")

        // Reads the site's <meta name="theme-color"> and reports it to the app,
        // now and whenever the site changes it (palette / dark-mode switch).
        private const val THEME_JS = """
            (function(){
              function push(){
                var m=document.querySelector('meta[name="theme-color"]');
                var c=m&&m.getAttribute('content');
                if(c&&window.SVApp){window.SVApp.setBars(c);}
              }
              push();
              if(!window.__svThemeObs){
                window.__svThemeObs=new MutationObserver(push);
                window.__svThemeObs.observe(document.head,
                  {subtree:true,attributes:true,childList:true,attributeFilter:['content']});
              }
            })();
        """
    }

    private lateinit var root: FrameLayout
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Splash stays up until the first page is on screen (or we give up after 8s).
    @Volatile private var ready = false

    // HTML5 fullscreen (video player)
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted && Build.VERSION.SDK_INT >= 33) {
                // After the 2nd denial Android stops showing the prompt: remember that.
                val blocked = !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
                prefs.edit().putBoolean("perm_blocked", blocked).apply()
            }
            jsCall("__svOnPermission", permissionState())
        }

    private fun permissionState(): String = when {
        NotificationManagerCompat.from(this).areNotificationsEnabled() -> "granted"
        Build.VERSION.SDK_INT < 33 || prefs.getBoolean("perm_blocked", false) -> "denied"
        else -> "default"
    }

    private fun jsCall(fn: String, arg: String) {
        val quoted = JSONObject.quote(arg)
        runOnUiThread { webView.evaluateJavascript("window.$fn && window.$fn($quoted)", null) }
    }

    private fun urlFromIntent(i: Intent?): String? {
        val raw = i?.getStringExtra(EXTRA_URL) ?: return null
        val full = if (raw.startsWith("/")) "https://$HOST$raw" else raw
        return if (Uri.parse(full).host == HOST) full else null
    }

    /** Called from the page's JavaScript (window.SVApp.setBars). */
    inner class Bridge {
        @JavascriptInterface
        fun setBars(color: String) {
            runOnUiThread { applyBarColor(color) }
        }

        /** "granted" | "default" (can still ask) | "denied" (must use phone settings) */
        @JavascriptInterface
        fun permission(): String = permissionState()

        /** Result arrives via window.__svOnPermission(state). */
        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread {
                if (permissionState() == "granted" || Build.VERSION.SDK_INT < 33) {
                    jsCall("__svOnPermission", permissionState())
                } else {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }

        /** Result arrives via window.__svOnToken(token) ("" on failure). */
        @JavascriptInterface
        fun requestToken() {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { t ->
                jsCall("__svOnToken", if (t.isSuccessful) (t.result ?: "") else "")
            }
        }

        @JavascriptInterface
        fun pushWanted(): Boolean = prefs.getBoolean("push_wanted", false)

        @JavascriptInterface
        fun setPushWanted(v: Boolean) {
            prefs.edit().putBoolean("push_wanted", v).apply()
        }

        @JavascriptInterface
        fun openSettings() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            }
        }
    }

    private fun applyBarColor(css: String) {
        val c = runCatching { Color.parseColor(css.trim()) }.getOrNull() ?: return
        root.setBackgroundColor(c)
        webView.setBackgroundColor(c)
        val light = ColorUtils.calculateLuminance(c) > 0.5
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = light       // dark icons on light bar
            isAppearanceLightNavigationBars = light
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen().setKeepOnScreenCondition { !ready }
        Notifications.ensureChannel(this)
        Handler(Looper.getMainLooper()).postDelayed({ ready = true }, 8000)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        webView = WebView(this)
        refresh = SwipeRefreshLayout(this).apply {
            addView(webView, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnRefreshListener { webView.reload() }
        }
        root = FrameLayout(this).apply {
            setBackgroundColor(getColor(R.color.splash_bg))   // until the site reports its own
            addView(refresh, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        setContentView(root)
        applyBarColor(String.format("#%06X", 0xFFFFFF and getColor(R.color.splash_bg)))

        // The status bar / nav bar / keyboard get their OWN space: the web page
        // is laid out only in the area left over, so nothing sits under them.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }

        // This app's own cookie + storage jar. Clearing Chrome does NOT touch it.
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        webView.addJavascriptInterface(Bridge(), "SVApp")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == HOST) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, url)) }
                return true
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                val path = runCatching { Uri.parse(url).path }.getOrNull() ?: ""
                refresh.isEnabled = NO_REFRESH_PATHS.none { path.startsWith(it) }
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                ready = true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) ready = true   // don't hold the splash if the load fails
            }

            override fun onPageFinished(view: WebView, url: String?) {
                ready = true
                refresh.isRefreshing = false
                CookieManager.getInstance().flush()
                if (Uri.parse(url).host == HOST) view.evaluateJavascript(THEME_JS, null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }

            // Fullscreen video support
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customViewCallback = callback
                root.addView(view, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
                view.setBackgroundColor(Color.BLACK)
                root.setPadding(0, 0, 0, 0)
                ViewCompat.setOnApplyWindowInsetsListener(root, null)
                WindowInsetsControllerCompat(window, window.decorView).apply {
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    hide(WindowInsetsCompat.Type.systemBars())
                }
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                WindowInsetsControllerCompat(window, window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
                ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
                    val i = insets.getInsets(
                        WindowInsetsCompat.Type.systemBars() or
                            WindowInsetsCompat.Type.displayCutout() or
                            WindowInsetsCompat.Type.ime()
                    )
                    v.setPadding(i.left, i.top, i.right, i.bottom)
                    WindowInsetsCompat.CONSUMED
                }
                ViewCompat.requestApplyInsets(root)
            }
        }

        webView.setDownloadListener { url, _, _, _, _ ->
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> webView.webChromeClient?.onHideCustomView()
                    webView.canGoBack() -> webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(urlFromIntent(intent) ?: START_URL)

        // Tapped a notification while the app was already open.
        addOnNewIntentListener { i -> urlFromIntent(i)?.let { webView.loadUrl(it) } }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
