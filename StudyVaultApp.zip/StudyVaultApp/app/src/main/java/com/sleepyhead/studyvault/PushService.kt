package com.sleepyhead.studyvault

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives pushes from your server (data-only messages) and shows them as
 * normal notifications with the StudyVault icon. Tapping opens `url` in the app.
 */
class PushService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        Notifications.show(
            this,
            d["title"] ?: "StudyVault",
            d["body"] ?: "",
            d["url"] ?: "/"
        )
    }

    // A new token is picked up and re-sent to the server the next time the
    // app opens (see the launch sync in index.php), so nothing to do here.
    override fun onNewToken(token: String) {}
}
